# lazysizes print extension

This simple print plugin for lazysizes will automatically unveil all element as soon as a print is detected even if the given lazyload image isn't in the viewport. 
